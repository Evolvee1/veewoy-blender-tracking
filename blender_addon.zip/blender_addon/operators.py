# operators.py
# Define custom Blender operators for the add-on here. 